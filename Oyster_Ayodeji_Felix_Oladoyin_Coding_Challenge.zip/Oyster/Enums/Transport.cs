﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oyster.Enums
{
    public enum Transport
    {
        BUS,
        TUBE
    }
}
