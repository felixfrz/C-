﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oyster.Constants
{
    public static class Station
    {
        public const string HOLBORN = "1";
        public const string EARLS_COURT = "1,2";
        public const string HAMMERSMITH = "2";
        public const string WIMBLEDON = "3";
    }
}
